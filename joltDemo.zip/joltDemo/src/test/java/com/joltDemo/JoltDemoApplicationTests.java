package com.joltDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoltDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
