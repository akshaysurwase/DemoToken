package com.joltDemo.service;

import com.joltDemo.model.JoltModel;
import com.joltDemo.repository.JoltRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class JoltService {
    @Autowired
    JoltRepository joltRepository;

    public JoltModel saveJoltSpec(JoltModel joltModel){
        return joltRepository.save(joltModel);
    }
}
