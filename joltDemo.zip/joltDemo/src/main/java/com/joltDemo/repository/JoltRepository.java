package com.joltDemo.repository;

import com.joltDemo.model.JoltModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface JoltRepository extends JpaRepository<JoltModel, Long> {
    Optional<JoltModel> findById(Long Id);

}
