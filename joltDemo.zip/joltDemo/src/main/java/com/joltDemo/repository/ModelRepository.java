package com.joltDemo.repository;

import com.joltDemo.model.JoltModel;
import com.joltDemo.model.Model;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModelRepository extends JpaRepository<Model, String> {


}
