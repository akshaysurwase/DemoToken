package com.joltDemo.model;



public class TransformationSpec {


    private String operation;
    private Spec spec;


}
