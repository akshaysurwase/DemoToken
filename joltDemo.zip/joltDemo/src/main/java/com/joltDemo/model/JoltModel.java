package com.joltDemo.model;

import com.bazaarvoice.jolt.JoltTransform;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
@Entity
public class JoltModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Lob
    public String objectName;

    @Column(columnDefinition = "jsonb")
    JsonNode transformationSpec;

    public Boolean isEnabled;
}
