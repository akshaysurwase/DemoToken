package com.joltDemo.model;

import java.util.List;

public class Spec {

    List<String> spec;
}
