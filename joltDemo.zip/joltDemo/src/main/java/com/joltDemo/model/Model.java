package com.joltDemo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import lombok.Data;

@Data
@Entity
public class Model {

    @Id
    public String fullName;

}
