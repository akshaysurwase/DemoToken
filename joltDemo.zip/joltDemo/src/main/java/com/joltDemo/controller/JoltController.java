package com.joltDemo.controller;

import com.bazaarvoice.jolt.Chainr;
import com.bazaarvoice.jolt.JoltTransform;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.joltDemo.model.JoltModel;
import com.joltDemo.model.JoltModelDto;
import com.joltDemo.model.Model;
import com.joltDemo.repository.JoltRepository;
import com.joltDemo.repository.ModelRepository;
import com.joltDemo.service.JoltService;
import org.hibernate.Remove;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.DataInput;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@RestController
public class JoltController {

    @Autowired
    JoltService joltService;

    @Autowired
    JoltRepository joltRepository;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    ModelRepository modelRepository;

/*    @PostMapping("/save")
    public ResponseEntity<String> save(@RequestBody JoltModel joltModel) throws JsonProcessingException {
        joltService.saveJoltSpec(joltModel);

        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode transformationSpecNode = objectMapper.readTree(joltModel.getTransformationSpec());


        JsonNode formattedTransformationSpec = objectMapper.createObjectNode()
                .set("operations", transformationSpecNode.path("operations"));


        System.out.println("Formatted transformationSpec: " + formattedTransformationSpec.toString());
        String fullName= "Akshay Surwase";



        Chainr chainr = Chainr.fromSpec(transformationSpecNode);
        JsonNode inputJson = objectMapper.createObjectNode().put("fullName", fullName);
        Object transformedOutput = chainr.transform(inputJson);


        System.out.println("Transformed Output: " + objectMapper.writeValueAsString(transformedOutput));



        return new ResponseEntity<>("Saved Succesfully", HttpStatus.CREATED);
    }*/

    @PostMapping("/save")
    public ResponseEntity<String> save(@RequestBody JoltModel joltModel) {
        try {
            joltService.saveJoltSpec(joltModel);

            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode transformationSpecNode = objectMapper.readTree(joltModel.getTransformationSpec());


            ArrayNode formattedTransformationSpec = objectMapper.createArrayNode();
            formattedTransformationSpec.add(transformationSpecNode);


            System.out.println("Formatted transformationSpec: " + formattedTransformationSpec.toString());

            String fullName = "Akshay Surwase";


            Chainr chainr = Chainr.fromSpec(formattedTransformationSpec);
            JsonNode inputJson = objectMapper.createObjectNode().put("fullName", fullName);
            Object transformedOutput = chainr.transform(inputJson);


            System.out.println("Transformed Output: " + objectMapper.writeValueAsString(transformedOutput));

            return new ResponseEntity<>("Saved Successfully", HttpStatus.CREATED);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return new ResponseEntity<>("Failed to process JSON", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/get")
    public ResponseEntity<List<JoltModel>> getall(){
        List<JoltModel> list =joltRepository.findAll();
        return new ResponseEntity<>(list,HttpStatus.OK);
    }

    private static List<Map<String, Object>> jsonStringToList(String jsonArrayString) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(jsonArrayString, new TypeReference<List<Map<String, Object>>>() {});
    }


 /*   @PostMapping("/save")
    public ResponseEntity<String> save(@RequestBody JoltModel joltModel) {
        try {
            joltService.saveJoltSpec(joltModel);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode transformationSpecNode = objectMapper.readValue(joltModel.getTransformationSpec(),JsonNode.class);

            Map<String, Object> map = objectMapper.convertValue(joltModel.getTransformationSpec(), Map.class);
            System.out.println(" map :"+ map);

            System.out.println("JSON NODE :"+ transformationSpecNode);
            ArrayList<Object> arrayList = (ArrayList<Object>) objectMapper.readValue(joltModel.getTransformationSpec(), List.class);
            System.out.println("ArrayList :"+arrayList);




            Chainr transformChainr = Chainr.fromSpec(arrayList);
            String fullName ="Akshay Surwase";
            JsonNode inputJson = objectMapper.createObjectNode().put("fullName", fullName);
            Object transformedOutput = transformChainr.transform(inputJson);
            System.out.println("transformedOutput " +transformedOutput);
            return new ResponseEntity<>("Saved Successfully", HttpStatus.CREATED);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return new ResponseEntity<>("Failed to process JSON", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }*/

    @GetMapping("/map")
    public String getMap() throws JsonProcessingException {
        // Create JSON string
        String json = "{\"operation\":\"modify-overwrite-beta\"," +
                "\"spec\":{\"inverseValue\":\"=divide(1, @(1,value2))\"," +
                "\"finalValue\":\"=divideAndRound(2, @(1,value1), @(1,inverseValue))\"}}";

        Map<String, Object> map = new ObjectMapper().readValue(json, Map.class);


//        ArrayList<Object> list = new ObjectMapper().readValue(json, ArrayList.class);

        System.out.println(map);
        return map.toString();
}

     @PostMapping("/ss")
        public String saving(@RequestBody JoltModelDto joltModelDto){
            JoltModel joltModel = new JoltModel();
            joltModel.setIsEnabled(joltModelDto.getIsEnabled());
            joltModel.setObjectName(joltModelDto.getObjectName());
            joltModel.setTransformationSpec(( joltModelDto.getTransformationSpec()).toString());
            joltRepository.save(joltModel);
            return "SAVEDDDDDD";
        }


       @PostMapping("/save")
    public ResponseEntity<String> save(@RequestBody JoltModel joltModel) {
        try {
            joltService.saveJoltSpec(joltModel);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode transformationSpecNode = objectMapper.readTree(String.valueOf(joltModel.getTransformationSpec()));


            ObjectNode objectNode = objectMapper.createObjectNode().setAll((ObjectNode) transformationSpecNode);

            ArrayList<Object> arrayList = (ArrayList<Object>) objectMapper.readValue( joltModel.getTransformationSpec(), List.class);
            System.out.println("ArrayList :"+arrayList);

            Chainr transformChainr = Chainr.fromSpec(arrayList);
            String fullName ="Akshay Surwase";
            JsonNode inputJson = objectMapper.createObjectNode().put("fullName", fullName);
            Object transformedOutput = transformChainr.transform(inputJson);
            System.out.println("transformedOutput " +transformedOutput);
            return new ResponseEntity<>("Saved Successfully", HttpStatus.CREATED);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return new ResponseEntity<>("Failed to process JSON", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }





    @DeleteMapping("/del")
    public String del(){
        joltRepository.deleteAll();
        return "deleted";
    }
/*

    @PostMapping("/model")
    public JsonNode modelSave(@RequestBody Model model) throws JsonProcessingException {
        JoltModel joltModel = joltRepository.findById(44L).orElseThrow();
        ArrayList<JsonNode> transformSpecs = (ArrayList<JsonNode>) objectMapper.readValue(joltModel.getTransformationSpec(), List.class);
        Chainr transformChainr = Chainr.fromSpec(transformSpecs);
        JsonNode inputJson = objectMapper.createObjectNode().put("fullName", model.getFullName());
        modelRepository.save(model);
        JsonNode transformedOutput = (JsonNode) transformChainr.transform(inputJson);
        return transformedOutput;
    }

    @PostMapping("/models")
    public Object modelSaves(@RequestBody Model model) throws JsonProcessingException {
        JoltModel joltModel = joltRepository.findById(44L).orElseThrow();
        ArrayList<JsonNode> transformSpecs = (ArrayList<JsonNode>) objectMapper.readValue(joltModel.getTransformationSpec(), List.class);


        JsonNode modelJson = objectMapper.valueToTree(model);

        Chainr transformChainr = Chainr.fromSpec(transformSpecs);

        modelRepository.save(model);


        Object transformedOutput = transformChainr.transform(modelJson);
        return transformedOutput;
    }

*/



}
