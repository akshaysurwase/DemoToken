package com.security.DemoToken;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTokenApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTokenApplication.class, args);
	}

}
