package com.security.DemoToken.Security;

import io.jsonwebtoken.*;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.util.Date;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;


public class RequestValidationBeforeFilter implements Filter {

    private static final String BEARER_AUTHENTICATION_SCHEME = "Bearer";

    @Value("${jwt.secret}")
    private String secret;


    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        String header = req.getHeader(AUTHORIZATION);

        if (header != null && header.startsWith(BEARER_AUTHENTICATION_SCHEME)) {
            String token = header.substring(7);

            try {
                // Extract claims directly from the token
                Jws<Claims> claimsJws = Jwts.parser()
                        .setSigningKey("AKSHAYhbchbajhvbfshbvhfvbhfbvuhfhcbduhbhncjncdhkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkchcdcjdncjdncjdnjdncjdcndjncjdncdjncd")
                        .parseClaimsJws(token);

                Claims claims = claimsJws.getBody();

                String username = claims.getSubject();
                Date expirationDate = claims.getExpiration();

                System.out.println("Username: " + username);
                System.out.println("Token expiration: " + expirationDate);

                // Continue processing the request with extracted claims
                chain.doFilter(request, response);
            } catch (JwtException e) {
                res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                if (e instanceof ExpiredJwtException) {
                    res.setHeader("Error", "Token expired");
                } else if (e instanceof UnsupportedJwtException) {
                    res.setHeader("Error", "Unsupported token format");
                } else if (e instanceof MalformedJwtException) {
                    res.setHeader("Error", "Malformed token");
                } else if (e instanceof SignatureException) {
                    res.setHeader("Error", "Invalid signature");
                } else {
                    res.setHeader("Error", "Invalid token");
                }
                return;
            }
        } else {
            chain.doFilter(request, response);
        }
    }
}




/*
public class RequestValidationBeforeFilter  implements Filter {

    public static final String BEARER_AUTHENTICATION_SCHEME = "Bearer";
    private Charset credentialsCharset = StandardCharsets.UTF_8;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        System.out.println(req.getUserPrincipal());

        System.out.println("The System Is INNNNNNNNNVVVVOOOOOOOOOKEEEEEEEEEEDDDDDDDDDD");

        HttpServletResponse res = (HttpServletResponse) response;
        String header = req.getHeader(AUTHORIZATION);
        if (header != null) {
            System.out.println("CUSRSOR IS HERE  IN IFFFFFFFFFFFFFF headr"+header);

            header = header.trim();
            if (StringUtils.startsWithIgnoreCase(header, BEARER_AUTHENTICATION_SCHEME)) {
                System.out.println("CUSRSOR IS HERE  IN TRY AUTHENTICATION_SCHEME_BASIC");

                byte[] base64Token = header.substring(6).getBytes(StandardCharsets.UTF_8);
                byte[] decoded;
                try {

                    System.out.println("CUSRSOR IS HERE  IN TRY");
                    decoded = Base64.getDecoder().decode(base64Token);
                    String token = new String(decoded, credentialsCharset);
                    System.out.println("Token is "+token);
                    int delim = token.indexOf(":");
                    if (delim == -1) {
                        throw new BadCredentialsException("Invalid basic authentication token");
                    }
                    String email = token.substring(0, delim);
                    if (email.toLowerCase().contains("test")) {
                        res.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                        return;
                    }
                } catch (IllegalArgumentException e) {
                    throw new BadCredentialsException("Failed to decode basic authentication token");
                }
            }
        }
        chain.doFilter(request, response);
    }
}
*/
