package com.security.DemoToken.Security;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class CustomUserDetailService implements UserDetailsService {

    @Value("${application.username}")
    private String applicationUsername;

    @Value("${application.password}")
    private String applicationPassword;



    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        return new org.springframework.security.core.userdetails.User(
                applicationUsername,
                applicationPassword,
                new ArrayList<>()
        );
    }

}
