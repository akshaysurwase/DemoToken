package com.security.DemoToken.Security;


import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.function.Function;


public class JwtTokenValidatorFilter extends OncePerRequestFilter {

    private static final String BEARER_AUTHENTICATION_SCHEME = "Bearer";

    @Value("${jwt.secret}")
    private String secret;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String header = request.getHeader("Authorization");

        if (header != null && header.startsWith(BEARER_AUTHENTICATION_SCHEME)) {
            String token = header.substring(7);

            try {
                Jwts.parser().setSigningKey("AKSHAYhbchbajhvbfshbvhfvbhfbvuhfhcbduhbhncjncdhkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkchcdcjdncjdncjdnjdncjdcndjncjdncdjncd").parseClaimsJws(token);

                String username = getClaimsFromToken(token, Claims::getSubject);


                System.out.println("Username from Token: " + username);

            } catch (ExpiredJwtException e) {
                throw new BadCredentialsException("JWT Token has expired");
            } catch (Exception e) {
                throw new BadCredentialsException("Invalid JWT Token received!");
            }
        }

        filterChain.doFilter(request, response);
    }

    private <T> T getClaimsFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = Jwts.parser().setSigningKey("AKSHAYhbchbajhvbfshbvhfvbhfbvuhfhcbduhbhncjncdhkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkchcdcjdncjdncjdnjdncjdcndjncjdncdjncd").parseClaimsJws(token).getBody();
        return claimsResolver.apply(claims);
    }
}


/*
public class JwtTokenValidatorFilter extends OncePerRequestFilter {

    private static final String SECRET_KEY = "AKSHAY";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String jwt = request.getHeader("Authorization");

        if (jwt != null && jwt.startsWith("Bearer ")) {
            jwt = jwt.substring(7);

            try {
                SecretKey key = new SecretKeySpec(SECRET_KEY.getBytes(StandardCharsets.UTF_8), SignatureAlgorithm.HS512.getJcaName());

                Claims claims = Jwts.parser()
                        .setSigningKey(key)
                        .parseClaimsJws(jwt)
                        .getBody();

                String username = String.valueOf(claims.get("username"));
                String authorities = (String) claims.get("authorities");


                System.out.println("Username from Token: " + username);

                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                        username, null, AuthorityUtils.commaSeparatedStringToAuthorityList(authorities)
                );

                SecurityContextHolder.getContext().setAuthentication(authToken);
            } catch (ExpiredJwtException e) {
                throw new BadCredentialsException("Jwt Token has expired");
            } catch (Exception e) {
                throw new BadCredentialsException("Invalid Token received!");
            }
        }

        filterChain.doFilter(request, response);
    }
}

*/
