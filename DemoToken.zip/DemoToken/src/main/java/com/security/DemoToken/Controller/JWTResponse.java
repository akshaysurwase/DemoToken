package com.security.DemoToken.Controller;

import lombok.Data;

@Data
public class JWTResponse {


    private final String jwtToken;

}
