package com.security.DemoToken;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTokenApplicationTests {

	@Test
	void contextLoads() {
	}

}
